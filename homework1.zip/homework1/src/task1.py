def greet():
    """Print 'Hello, World!' to the console"""

    print("Hello, World!")


if __name__ == "__main__":
    greet()
