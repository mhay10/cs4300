def get_datatypes():
    """Returns a dictionary with examples of different datatypes"""

    return {
        "int": 3,
        "float": 4.12,
        "str": "test",
        "bool": False,
    }


if __name__ == "__main__":
    print("Datatype examples:", get_datatypes())
